package com.example.convertTemp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConvertTempApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConvertTempApplication.class, args);
	}

}
